To compile:
	javac *.java
	(Expression.java Statement.java Robol.java)

To run:
	java Test 
	(Runs the testprograms from the task)